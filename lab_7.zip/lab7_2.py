'''
Dev YSong

Des: Create a script that allows people to store household item name and the
number in storage by using pickling method

--------------------------------------------------------------------------'''
import pickle
intId = int(input("Enter the number of the household item: "))
strName = str(input("Enter a Name of the item: "))
lstHouseholdItem = [intId, strName]
print(lstHouseholdItem)

#Now we store the data with the pickle.dump method

objFile = open ("Storage.dat", "ab")
pickle.dump(lstHouseholdItem, objFile)
objFile.close()

#We read the data back with the same pickle.load method
objFile = ("Storage.dat", "rb")
objFileData = pickle.load(objFile) #Note that load() only load one row of data
print(objFileData)
objFileData = pickle.load(objFile)
print(objFileData)

objFile.close

