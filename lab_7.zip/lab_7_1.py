'''
Dev YSong

Des: Create a script that allows people to store household item name and the left
number in store

Changlog:
YSong, 11/13/17, Adding error handling code
-------------------------------------------------------------------------'''

#Data
objFile = None #File Handle
strUserInput = None # A string which holds user input

#Processing
def WriteUserInput(File):
    try:
        print("Type in a Household Item Name and Number you want to add to the file")
        print("(Enter 'Exit' to quit!)")
        while True:
            strUserInput = input("Enter the Name and Number (ex. lamp, 6): ")
            if(strUserInput.lower() == "exit"):break
            else: File.write(strUserInput + "\n")
    except Exception as e:
        print("Error: "+ str(e))
        
def ReadAllFileData(File, Message="Contents of File"):
    try:
        print(Message)
        File.seek(0)
        print(objFile.read())
    except:
        print()

#I/O
try:
    objFile = open ("Storage.txt", "w+")
    
    ReadAllFileData(objFile, "Here is the current data in storage:")

    WriteUserInput(objFile)

    ReadAllFileData(objFile, "Here is the data was saved:")
except:
    print("error")
finally:
    if(objFile != None):objFile.close()
